#welcome to my project website.

**firstlly- run the website:**
open : FulstackDaniel

##Project structure:##

1. FulstackDaniel.html- The code HTML.
2. Images- my profile.


The project is one page in HTML that present my Hobbies,education and sent mail to mail if you want.

Every subject connected by:

##Project Description:££
1 HTML FILE 


